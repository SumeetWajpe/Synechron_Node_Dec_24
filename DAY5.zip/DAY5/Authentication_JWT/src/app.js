const express = require("express");
const app = express();
const jwt = require("jsonwebtoken");
const secretKey = "MySecretKey";
app.get("/sign", (req, res) => {
  jwt.sign(
    { uname: "Sumeet" },
    secretKey,
    {
      expiresIn: "2 Days",
      algorithm: "HS256",
    },
    (err, token) => {
      return res.json({ token });
    },
  );
});

app.post("/verify", (req, res) => {
  try {
    if (req.headers.authorization) {
      let authValue = req.headers.authorization;
      let token = authValue.split(" ")[1]; // Bearer token
      jwt.verify(token, secretKey, (err, decodedToken) => {
        if (!err) {
          console.log(decodedToken);
          return res.json({ success: "Authenticated !" });
        } else {
          return res.status(401).send("Invalid token");
        }
      });
    } else {
      return res.status(500).send("Token Missing !");
    }
  } catch (error) {
    console.log(error);
  }
});

app.listen(3000, () => {
  console.log("App running @ port 3000 !");
});
