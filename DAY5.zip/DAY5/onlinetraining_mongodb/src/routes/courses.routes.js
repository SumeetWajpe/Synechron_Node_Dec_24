import express from "express";
import path from "path";
import fs from "fs";
import Courses from "../models/courses.js";

const router = express.Router();
router.get("/courses", async function (req, res, next) {
  try {
    let _courses = await Courses.find({});
    console.log(_courses);
    return res.json(_courses);
  } catch (error) {
    console.log(error);
  }
});

router.get("/coursedetails/:id", async (req, res) => {
  try {
    let courseId = req.params.id;
    let theCourse = await Courses.findOne({ id: courseId });
    console.log(theCourse);
    // coursedetails - html -> send to the client
    res.render("coursedetails", { title: "Course details", theCourse });
  } catch (error) {
    console.log(error);
  }
});

router.post("/newcourse", async (req, res) => {
  try {
    let newCourse = req.body;

    let newCourseToBeInserted = new Courses({ ...newCourse });
    let result = await newCourseToBeInserted.save();

    return res.json({ msg: `The ${newCourse.title} was added successfully !` });
  } catch (error) {}
});

router.get("/video", (req, res) => {
  // access the video
  const videoPath = path.resolve(
    path.dirname(".") + "/src/videos",
    "bunny.mp4",
  );

  const videoSize = fs.statSync(videoPath).size;

  const CHUNK_SIZE = 10 ** 6; // 1MB

  // range
  const range = req.headers.range;

  const start = Number(range.replace(/\D/g, ""));
  const end = Math.min(start + CHUNK_SIZE, videoSize - 1);
  const contentLength = end - start + 1;

  const headers = {
    "Content-Type": "video/mp4",
    "content-range": `bytes ${start}-${end}/${videoSize}`,
    "Accept-Ranges": "bytes",
    "Content-Length": contentLength,
  };
  res.writeHead(206, headers);

  const videoStream = fs.createReadStream(videoPath, { start, end });
  videoStream.pipe(res);
});

export default router;
