import mongoose from "mongoose";

const Schema = mongoose.Schema;

const coursesSchema = new Schema({
  id: String,
  title: String,
  price: Number,
  rating: Number,
  likes: Number,
  trainer: String,
  imageUrl: String,
  description: String,
});
const Courses = mongoose.model("courses", coursesSchema);

export default Courses;
