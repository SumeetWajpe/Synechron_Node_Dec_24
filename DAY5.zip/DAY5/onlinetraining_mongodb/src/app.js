import express from "express";
import coursesRouter from "./routes/courses.routes.js";
import mongoose from "mongoose";

const app = express();
const port = 3000;

// middleware
app.use(express.json());
app.use(express.static("public"));

// view engine
app.set("view engine", "pug");
app.set("views", "./src/views");

mongoose.connect(
  "mongodb+srv://sumeet-wajpe:7Tw8wGzAuJy5Wgsp@cluster0.urwyk.mongodb.net/coursesdb?retryWrites=true&w=majority&appName=Cluster0",
);

mongoose.connection.once("open", () => {
  // console.log("Connected to onlineshoppingdb !");
  console.log("Connected to coursesdb !");
});

// routers
app.use("/", coursesRouter);

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
