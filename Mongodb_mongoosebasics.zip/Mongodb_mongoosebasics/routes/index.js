var express = require("express");
const Products = require("../models/products.model");
var router = express.Router();

/* GET home page. */
router.get("/", async function (req, res, next) {
  try {
    // get the products // render them
    let products = await Products.find({});
    return res.json(products);

    //res.render("index", { title: "Express" });
  } catch (error) {}
});

module.exports = router;
